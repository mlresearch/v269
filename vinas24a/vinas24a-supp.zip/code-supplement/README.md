# Simple GNNs with Low Rank Non-parametric Aggregators

## Requirements

Dependencies: `torch`, `optuna`, `numpy`, `xarray`, `torch_geometric`, `tqdm`

## Training

To train the model(s) in the paper, run this command:

```train
python low_rank_sweep.py --masks balanced --graphs none shift --save_name table1_results
```

## Evaluation

To find validation and test values, read-in xarray table as

```eval
>>> import xarray as xr
>>> result_xr = xr.load_dataset('sweep_results/table1_results.nc')['__xarray_dataarray_variable__']
```

## Other Results

MLP2 results can be obtained by running `mlp_run.py`

Comparison of different evaluation is run using `eval_conventions.py`