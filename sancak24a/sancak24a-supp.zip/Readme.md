We built upon SGFormer code base, below are their instructions:

For medium sized datasets, we use `--use_nasc` to utilize nasc.

For large sized datasets, you can utilize nasc using two options: ` --gnn_use_nasc ${type} --gnn_nasc_param {param}`
$type can be: sum or adaptive

If $type is `adaptive` and `gnn_nasc_param=0`, we set `q = 1`. Otherwise, we set `q=hidden dim`.
If $type is `sum` then `gnn_nasc_param=alpha` sets a constant multiplier to residual terms, which is set to `1` by default.

## Dataset

One can download the datasets (Planetoid, Deezer, Pokec, Actor/Film) from the google drive link below:

https://drive.google.com/drive/folders/1rr3kewCBUvIuVxA6MJ90wzQuF-NnCRtf?usp=drive_link

For Chameleon and Squirrel, we use the [new splits](https://github.com/yandex-research/heterophilous-graphs/tree/main) that filter out the overlapped nodes.

For the OGB datasets, they will be downloaded automatically when running the code.
