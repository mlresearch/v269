"""Definition of valid tasks."""
