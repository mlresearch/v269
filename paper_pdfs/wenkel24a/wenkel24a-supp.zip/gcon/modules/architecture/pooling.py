import torch


def pooling_operation(
        data,
        type: str,
    ):

    return None